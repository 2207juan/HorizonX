#!/usr/bin/env python3
"""Portable entry point, Python 3.10+. Importing does not connect to any television."""
from horizonx.__main__ import main
from horizonx.adb import Error
import sys
if __name__ == '__main__':
    try:
        if len(sys.argv) == 1:
            # Double-click: guided menu. Any argument keeps the full command-line assistant.
            from horizonx.guide import main as guide
            sys.exit(guide())
        sys.exit(main())
    except (Error, OSError, ValueError, KeyError, TypeError) as e:
        print(f'HorizonX: {e}', file=sys.stderr)
        sys.exit(2)
    except KeyboardInterrupt:
        sys.exit(130)
