# Asistente HorizonX (PC)

Doble clic en `HorizonX.sh` (Linux/macOS) o `HorizonX.cmd` (Windows) para abrir el **menú guiado**: conectar, instalar, optimizar, deshacer y comprobar la compatibilidad. Requiere Python 3.10+ y Android Platform Tools (en el PATH o en `platform-tools/` dentro de esta carpeta).

Con argumentos funciona el asistente avanzado de línea de órdenes (`python3 horizonx.py --help`).

- `horizonx/optimize.py`: plan por modelo, copia de seguridad, `pm disable-user` y restauración.
- `horizonx/guide.py`: menú guiado.
- `profiles/tv-database.json`: 252 modelos (CleanYourTV, MIT). `profiles/platforms.json`: qué permite cada sistema.

Guía completa: [../docs/GUIA.md](../docs/GUIA.md).
