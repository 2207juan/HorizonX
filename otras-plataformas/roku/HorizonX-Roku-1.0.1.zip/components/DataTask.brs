sub init()
    m.top.functionName = "runTask"
end sub

sub runTask()
    if m.top.request = "weather" then
        m.top.result = { kind: "weather", value: weather() }
    else
        services = installedServices()
        m.top.result = { kind: "explore", services: services, items: explore(services) }
    end if
end sub

function getJson(url as String) as Dynamic
    t = CreateObject("roUrlTransfer")
    t.SetUrl(url)
    t.SetCertificatesFile("common:/certs/ca-bundle.crt")
    t.InitClientCertificates()
    t.AddHeader("User-Agent", "HorizonX/1.0 (Roku)")
    body = t.GetToString()
    if body = invalid or body = "" then return invalid
    return ParseJson(body)
end function

' Weather: approximate location from the public IP (two providers), then Open-Meteo. WMO codes.
function weather() as Dynamic
    place = getJson("https://ipwho.is/?fields=latitude,longitude")
    if place = invalid or place.latitude = invalid then
        geo = getJson("https://get.geojs.io/v1/ip/geo.json")
        if geo = invalid or geo.latitude = invalid then return invalid
        place = { latitude: Val(geo.latitude), longitude: Val(geo.longitude) }
    end if
    w = getJson("https://api.open-meteo.com/v1/forecast?latitude=" + place.latitude.ToStr() + "&longitude=" + place.longitude.ToStr() + "&current=temperature_2m,weather_code,is_day")
    if w = invalid or w.current = invalid then return invalid
    code = w.current.weather_code
    day = (w.current.is_day = 1)
    label = "Nublado"
    if code = 0 then
        if day then label = "Soleado" else label = "Despejado"
    else if code = 1 then
        label = "Despejado"
    else if code = 2 then
        label = "Parcialmente nublado"
    else if code = 45 or code = 48 then
        label = "Niebla"
    else if code >= 51 and code <= 57 then
        label = "Llovizna"
    else if (code >= 61 and code <= 67) or (code >= 80 and code <= 82) then
        label = "Lluvia"
    else if (code >= 71 and code <= 77) or code = 85 or code = 86 then
        label = "Nieve"
    else if code >= 95 then
        label = "Tormenta"
    end if
    return { celsius: Int(w.current.temperature_2m + 0.5), label: label }
end function

' Roku channel IDs of common services (as used by ECP). Only checked with IsAppInstalled.
function knownServices() as Object
    return [
        { id: "12", name: "Netflix", channels: ["netflix"], color: "#e50914" },
        { id: "837", name: "YouTube", channels: ["youtube"], color: "#ff0000" },
        { id: "13", name: "Prime Video", channels: ["prime video", "amazon prime video"], color: "#1a98ff" },
        { id: "291097", name: "Disney+", channels: ["disney+"], color: "#113ccf" },
        { id: "61322", name: "Max", channels: ["hbo max", "max"], color: "#002be7" },
        { id: "31440", name: "Paramount+", channels: ["paramount+"], color: "#0064ff" },
        { id: "551012", name: "Apple TV", channels: ["apple tv+", "apple tv"], color: "#1c1c1e" },
        { id: "2285", name: "Hulu", channels: ["hulu"], color: "#1ce783" },
        { id: "593099", name: "Peacock", channels: ["peacock"], color: "#111111" },
        { id: "2595", name: "Crunchyroll", channels: ["crunchyroll"], color: "#f47521" },
        { id: "22297", name: "Spotify", channels: [], color: "#1db954" },
        { id: "74519", name: "Pluto TV", channels: ["pluto tv"], color: "#2c2c2c" },
        { id: "41468", name: "Tubi", channels: ["tubi"], color: "#7408ff" },
        { id: "151908", name: "The Roku Channel", channels: ["the roku channel"], color: "#6c3c97" }
    ]
end function

function installedServices() as Object
    apps = CreateObject("roAppManager")
    out = []
    for each s in knownServices()
        if apps.IsAppInstalled(s.id, "") then out.Push(s)
    end for
    return out
end function

function dateString(daysAgo as Integer) as String
    d = CreateObject("roDateTime")
    d.FromSeconds(d.AsSeconds() - daysAgo * 86400)
    d.ToLocalTime()
    mm = Right("0" + d.GetMonth().ToStr(), 2)
    dd = Right("0" + d.GetDayOfMonth().ToStr(), 2)
    return d.GetYear().ToStr() + "-" + mm + "-" + dd
end function

' Four days of streaming premieres, unique shows by popularity, kept to the installed services.
function explore(services as Object) as Object
    byChannel = {}
    for each s in services
        for each c in s.channels
            byChannel[c] = s
        end for
    end for
    seen = {}
    shows = []
    for n = 0 to 3
        list = getJson("https://api.tvmaze.com/schedule/web?date=" + dateString(n))
        if list <> invalid then
            for each e in list
                s = invalid
                if e._embedded <> invalid then s = e._embedded.show
                if s <> invalid and s.image <> invalid and seen[s.id.ToStr()] = invalid then
                    seen[s.id.ToStr()] = true
                    channel = ""
                    if s.webChannel <> invalid then
                        channel = s.webChannel.name
                    else if s.network <> invalid then
                        channel = s.network.name
                    end if
                    svc = byChannel[LCase(channel)]
                    if svc <> invalid or services.Count() = 0 then
                        genre = ""
                        if s.genres <> invalid and s.genres.Count() > 0 then genre = s.genres[0]
                        image = s.image.medium
                        if image = invalid then image = s.image.original
                        weight = 0
                        if s.weight <> invalid then weight = s.weight
                        app = channel
                        if svc <> invalid then app = svc.name
                        shows.Push({ title: s.name, poster: image.Replace("http://", "https://"), genre: genre, app: app, weight: weight })
                    end if
                end if
            end for
        end if
    end for
    ' Most popular first, then a daily shuffle of the rest (same order all day).
    shows.SortBy("weight", "r")
    head = []
    rest = []
    for i = 0 to shows.Count() - 1
        if i < 3 then head.Push(shows[i]) else rest.Push(shows[i])
    end for
    seed = Int(CreateObject("roDateTime").AsSeconds() / 86400) mod 65537
    for i = rest.Count() - 1 to 1 step -1
        ' Small LCG: BrightScript Integer is 32-bit, so keep the product under 2^31.
        seed = (seed * 75 + 74) mod 65537
        j = Int(seed / 65537 * (i + 1))
        tmp = rest[i]
        rest[i] = rest[j]
        rest[j] = tmp
    end for
    head.Append(rest)
    out = []
    for i = 0 to head.Count() - 1
        if i < 18 then out.Push(head[i])
    end for
    return out
end function
