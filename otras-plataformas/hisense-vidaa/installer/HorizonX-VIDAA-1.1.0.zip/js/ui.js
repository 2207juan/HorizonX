// Home screen rendering and remote navigation. Focus moves between explicit zones, like the
// Android version: header buttons, tabs, the content rail and the 7-column app grid.
(function (HX) {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var UI = HX.ui = { zone: 'rail', header: 0, tab: 0, rail: 0, app: 0, cards: [], tiles: [], moving: null, explore: [], apps: [] };
  var COLS = 7, TW = 220, TH = 124, GAP = 32, ROW = 184, LEFT = (1920 - (COLS * TW + (COLS - 1) * GAP)) / 2;

  // Sounds: shared HorizonX samples, tiny and preloaded. Two players so quick moves overlap.
  var tick = [new Audio('sounds/nav_tick.wav'), new Audio('sounds/nav_tick.wav')], tickIdx = 0, select = new Audio('sounds/nav_select.wav'), lastTick = 0;
  tick.concat([select]).forEach(function (a) { a.volume = 0.35; a.preload = 'auto'; });
  function play(a) { try { a.currentTime = 0; var pending = a.play(); if (pending && typeof pending.catch === 'function') { pending.catch(function () { /* paused or autoplay denied */ }); } } catch (e) { /* older TV autoplay */ } }
  UI.move = function () { if (!HX.data.settings.sounds) { return; } var now = Date.now(); if (now - lastTick < 45) { return; } lastTick = now; play(tick[tickIdx = 1 - tickIdx]); };
  UI.confirm = function () { if (!HX.data.settings.sounds) { return; } play(select); };

  UI.toast = function (text) {
    var t = $('toast'); t.textContent = text; t.hidden = false;
    clearTimeout(UI.toastTimer); UI.toastTimer = setTimeout(function () { t.hidden = true; }, 2600);
  };

  UI.clock = function () {
    var now = new Date(), lang = HX.lang;
    var h = now.getHours(), m = ('0' + now.getMinutes()).slice(-2);
    $('clock').textContent = h + ':' + m;
    var day, month;
    try { day = now.toLocaleDateString(lang, { weekday: 'short' }); month = now.toLocaleDateString(lang, { month: 'short' }); } catch (e) { day = ''; month = ''; }
    var date = (day + ' ' + now.getDate() + ' ' + month).replace(/\./g, '');
    $('date').textContent = date.charAt(0).toUpperCase() + date.slice(1);
  };
  /** Icon, temperature, condition with today's range and city, then the next three days. */
  UI.weather = function (w) {
    var box = $('weatherBox');
    if (!w || !HX.data.settings.weather) { box.hidden = true; return; }
    $('weatherIcon').className = 'ico big ico-' + w.icon;
    $('temp').textContent = w.celsius + '°';
    $('wlabel').textContent = HX.t(w.label);
    $('wrange').textContent = [w.max != null ? w.max + '° / ' + w.min + '°' : '', w.city || ''].filter(Boolean).join('  ·  ');
    var days = $('wdays'); days.innerHTML = '';
    (w.days || []).forEach(function (d) {
      var el = document.createElement('div'), name = '';
      try { name = new Date(d.date + 'T12:00:00').toLocaleDateString(HX.lang, { weekday: 'short' }).replace(/\./g, ''); } catch (e) { name = d.date.slice(5); }
      el.className = 'wday';
      el.innerHTML = '<small></small><i class="ico ico-' + d.icon + '"></i>' + d.max + '°';
      el.firstChild.textContent = name.charAt(0).toUpperCase() + name.slice(1);
      days.appendChild(el);
    });
    days.hidden = !(w.days || []).length;
    box.hidden = false;
  };

  // ---------------------------------------------------------------- focus backdrop
  // The focused show's art full screen (or the app's brand colour), after a short dwell so
  // fast scrolling never loads pictures. Two layers cross-fade; only opacity/transform animate.
  var spotFront = 0, spotKey = null, spotTimer = 0;
  UI.suspend = function () { clearTimeout(spotTimer); tick.concat([select]).forEach(function (a) { a.pause(); }); };
  UI.spot = function (key, image, poster, color) {
    clearTimeout(spotTimer);
    if (!HX.data.settings.spotlight) { key = null; }
    if (key === spotKey) { return; }
    spotTimer = setTimeout(function () {
      spotKey = key;
      var layers = [$('spotA'), $('spotB')], next = layers[1 - spotFront], old = layers[spotFront];
      if (!key) { old.className = 'layer'; next.className = 'layer'; $('spot').className = ''; return; }
      next.style.backgroundImage = image ? 'url("' + image + '")' : 'radial-gradient(ellipse at 80% 20%, ' + color + ' 0%, rgba(10,12,23,1) 75%)';
      next.style.backgroundColor = color || '#0a0c17';
      next.className = 'layer' + (poster ? ' poster' : '');
      next.offsetWidth; // restart the settle from scale(1.07)
      next.className += ' on'; old.className = old.className.replace(' on', '');
      spotFront = 1 - spotFront; $('spot').className = 'on';
    }, 260);
  };
  function spotItem(it) {
    if (!it || it.empty) { return; }
    if (it.appRef) { spotApp(it.appRef); return; }
    UI.spot('i:' + (it.wide || it.image), it.wide || it.image, !it.wide, '#0a0c17');
  }
  function spotApp(app) {
    var b = HX.platform.brandOf(app.name, app.id) || {};
    var show = UI.explore.filter(function (it) { return it.app && it.app.id === app.id && (it.wide || it.image); })[0];
    if (show) { UI.spot('i:' + (show.wide || show.image), show.wide || show.image, !show.wide, b.bg); }
    else { UI.spot('a:' + app.id, null, false, b.bg || '#253240'); }
  }

  UI.profile = function () {
    var s = HX.data.settings;
    $('hello').textContent = s.name ? HX.t('helloName', { name: s.name }) : HX.t('hello');
    $('question').textContent = HX.t('question');
    $('avatar').src = 'img/avatar-' + s.avatar + '.png';
    $('tabExplore').textContent = HX.t('explore');
    $('tabRecent').textContent = HX.t('recent');
    $('dockTitle').textContent = HX.t('apps');
  };

  // ---------------------------------------------------------------- content rail
  function brandTile(el, app) {
    var b = HX.platform.brandOf(app.name, app.id);
    if (app.icon) { el.style.backgroundImage = 'url("' + app.icon + '")'; el.textContent = ''; }
    else { el.textContent = app.name; }
    if (b && b.bg) { el.style.backgroundColor = b.bg; el.style.color = b.fg || '#fff'; }
  }
  UI.renderRail = function () {
    var track = $('track'); track.innerHTML = ''; UI.cards = [];
    var items = UI.tab === 0 ? UI.explore : UI.recentItems();
    if (!items.length) { items = [{ title: HX.t(UI.tab === 0 ? 'explore' : 'recent'), meta: HX.t('emptyRecent'), empty: true }]; }
    var x = 0;
    items.forEach(function (it, i) {
      var hero = i === 0, w = hero ? 704 : it.appRef ? 400 : 208;
      var card = document.createElement('div'); card.className = 'card' + (hero ? ' hero' : '');
      card.style.left = x + 'px'; card.style.width = w + 'px';
      var art = document.createElement('div'); art.className = 'art';
      if (it.image) { art.style.backgroundImage = 'url("' + ((hero && it.wide) || it.image) + '")'; }
      else if (it.appRef) { brandTile(art, it.appRef); art.style.backgroundSize = '40%'; }
      else { var ph = document.createElement('div'); ph.className = 'placeholder'; ph.textContent = it.title; art.appendChild(ph); }
      if (!it.empty) { var badge = document.createElement('div'); badge.className = 'badge'; badge.textContent = HX.t(it.appRef ? 'open' : 'watchNow'); art.appendChild(badge); }
      var title = document.createElement('div'); title.className = 'title'; title.textContent = it.title;
      var meta = document.createElement('div'); meta.className = 'meta'; meta.textContent = it.meta || '';
      card.appendChild(art); card.appendChild(title); card.appendChild(meta);
      track.appendChild(card);
      UI.cards.push({ el: card, x: x, w: w, item: it });
      x += w + 36;
    });
    UI.rail = Math.min(UI.rail, UI.cards.length - 1);
    UI.scrollRail(false);
  };
  UI.recentItems = function () {
    return HX.data.settings.recent.map(function (r) {
      var app = UI.apps.filter(function (a) { return a.id === r.id; })[0];
      return app ? { title: HX.t('backTo', { app: app.name }), meta: '', appRef: app, wideApp: true } : null;
    }).filter(Boolean);
  };
  UI.scrollRail = function (animate) {
    var c = UI.cards[UI.rail]; if (!c) { return; }
    var total = UI.cards[UI.cards.length - 1].x + UI.cards[UI.cards.length - 1].w, max = Math.max(0, total - 1728);
    var target = -Math.min(c.x, max);
    var track = $('track'); track.style.transition = animate === false ? 'none' : '';
    track.style.webkitTransform = track.style.transform = 'translateX(' + target + 'px)';
  };

  // ---------------------------------------------------------------- app grid
  UI.orderedApps = function () {
    var s = HX.data.settings, byId = {};
    UI.apps.forEach(function (a) { byId[a.id] = a; });
    var out = [];
    s.order.forEach(function (id) { if (byId[id]) { out.push(byId[id]); delete byId[id]; } });
    UI.apps.forEach(function (a) { if (byId[a.id]) { out.push(a); } });
    return out.filter(function (a) { return s.hidden.indexOf(a.id) < 0; });
  };
  UI.renderGrid = function () {
    var grid = $('grid'); grid.innerHTML = ''; UI.tiles = [];
    UI.orderedApps().forEach(function (a, i) {
      var el = document.createElement('div'); el.className = 'app';
      el.style.left = (LEFT + (i % COLS) * (TW + GAP)) + 'px'; el.style.top = (Math.floor(i / COLS) * ROW) + 'px';
      var tile = document.createElement('div'); tile.className = 'tile'; brandTile(tile, a);
      var label = document.createElement('div'); label.className = 'label'; label.textContent = a.name;
      el.appendChild(tile); el.appendChild(label); grid.appendChild(el);
      UI.tiles.push({ el: el, app: a });
    });
    UI.app = Math.min(UI.app, Math.max(0, UI.tiles.length - 1));
  };
  function gridRows() { return Math.ceil(UI.tiles.length / COLS); }
  function placeGrid() {
    var row = Math.floor(UI.app / COLS), open = UI.zone === 'apps' && row >= 1;
    $('dock').className = open ? 'open' : '';
    $('stage').className = open ? 'away' : '';
    document.body.className = open ? 'dockOpen' : '';
    var first = open ? Math.max(0, row - 3) : 0;
    var g = $('grid'); g.style.webkitTransform = g.style.transform = 'translateY(' + (-first * ROW + (open ? 40 : 0)) + 'px)';
  }

  // ---------------------------------------------------------------- focus
  function clearFocus() { var f = document.querySelectorAll('.focus'); for (var i = 0; i < f.length; i++) { f[i].classList.remove('focus'); } }
  UI.paint = function () {
    clearFocus();
    if (UI.zone === 'header') { document.querySelectorAll('[data-zone=header]')[UI.header].classList.add('focus'); }
    if (UI.zone === 'tabs') { document.querySelectorAll('.tab')[UI.tab].classList.add('focus'); }
    if (UI.zone === 'rail' && UI.cards[UI.rail]) { UI.cards[UI.rail].el.classList.add('focus'); spotItem(UI.cards[UI.rail].item); }
    if (UI.zone === 'apps' && UI.tiles[UI.app]) { UI.tiles[UI.app].el.classList.add('focus'); if (UI.app < COLS) { spotApp(UI.tiles[UI.app].app); } }
    var tabs = document.querySelectorAll('.tab'), active = tabs[UI.tab], line = $('tabLine');
    for (var i = 0; i < tabs.length; i++) { tabs[i].classList.toggle('active', i === UI.tab); }
    line.style.left = (active.offsetLeft + 22) + 'px'; line.style.width = (active.offsetWidth - 44) + 'px';
    placeGrid();
  };
  UI.go = function (zone) { if (zone !== UI.zone) { UI.zone = zone; UI.move(); } UI.paint(); };

  UI.key = function (k) {
    var K = HX.platform.KEY;
    if (UI.moving) { return moveKey(k); }
    if (k === K.LEFT || k === K.RIGHT) {
      var d = k === K.LEFT ? -1 : 1;
      if (UI.zone === 'header') { UI.header = clamp(UI.header + d, 0, 1); }
      else if (UI.zone === 'tabs') { var t = clamp(UI.tab + d, 0, 1); if (t !== UI.tab) { UI.tab = t; UI.rail = 0; UI.renderRail(); } }
      else if (UI.zone === 'rail') { UI.rail = clamp(UI.rail + d, 0, UI.cards.length - 1); UI.scrollRail(); }
      else if (UI.zone === 'apps') { var col = UI.app % COLS; if ((d < 0 && col > 0) || (d > 0 && col < COLS - 1 && UI.app < UI.tiles.length - 1)) { UI.app += d; } }
      UI.move(); UI.paint(); return true;
    }
    if (k === K.UP) {
      if (UI.zone === 'apps' && UI.app >= COLS) { UI.app -= COLS; UI.move(); UI.paint(); }
      else if (UI.zone === 'apps') { UI.go('rail'); }
      else if (UI.zone === 'rail') { UI.go('tabs'); }
      else if (UI.zone === 'tabs') { UI.header = 0; UI.go('header'); }
      return true;
    }
    if (k === K.DOWN) {
      if (UI.zone === 'header') { UI.go('tabs'); }
      else if (UI.zone === 'tabs') { UI.go('rail'); }
      else if (UI.zone === 'rail') { UI.app = 0; UI.go('apps'); }
      else if (UI.zone === 'apps' && Math.floor(UI.app / COLS) < gridRows() - 1) { UI.app = Math.min(UI.app + COLS, UI.tiles.length - 1); UI.move(); UI.paint(); }
      return true;
    }
    if (k === K.BACK || k === K.ESC) {
      if (UI.zone === 'apps' && UI.app >= COLS) { UI.app %= COLS; UI.paint(); }
      else if (UI.zone !== 'rail') { UI.go('rail'); }
      else if (UI.rail > 0) { UI.rail = 0; UI.scrollRail(); UI.paint(); }
      return true;
    }
    return false;
  };
  UI.activate = function () {
    UI.confirm();
    if (UI.zone === 'header') { HX.panel.open(UI.header === 0 ? 1 : 0); return; }
    if (UI.zone === 'tabs') { UI.go('rail'); return; }
    if (UI.zone === 'rail') {
      var it = UI.cards[UI.rail] && UI.cards[UI.rail].item; if (!it || it.empty) { return; }
      var app = it.appRef || it.app; if (app) { UI.launch(app); } else { UI.toast(it.title); }
      return;
    }
    if (UI.zone === 'apps' && UI.tiles[UI.app]) { UI.launch(UI.tiles[UI.app].app); }
  };
  UI.launch = function (app) { HX.data.remember(app); HX.platform.launch(app.id, function () { UI.toast(HX.t('notAvailable')); }); };

  // Hold OK on an app: lift it, arrows move it, OK or Back drops it.
  UI.longPress = function () {
    if (UI.zone !== 'apps' || !UI.tiles[UI.app]) { return; }
    UI.moving = UI.tiles[UI.app].app.id; UI.tiles[UI.app].el.classList.add('moving'); UI.confirm();
    UI.toast(HX.t('move', { app: UI.tiles[UI.app].app.name }));
  };
  function moveKey(k) {
    var K = HX.platform.KEY, ids = UI.orderedApps().map(function (a) { return a.id; }), from = ids.indexOf(UI.moving);
    if (from < 0) { UI.moving = null; UI.renderGrid(); UI.paint(); return true; }
    if (k === K.ENTER || k === K.BACK || k === K.ESC) { UI.moving = null; UI.renderGrid(); UI.paint(); UI.confirm(); return true; }
    var to = from + (k === K.LEFT ? -1 : k === K.RIGHT ? 1 : k === K.UP ? -COLS : k === K.DOWN ? COLS : 0);
    to = clamp(to, 0, ids.length - 1); if (to === from) { return true; }
    ids.splice(to, 0, ids.splice(from, 1)[0]);
    HX.data.settings.order = ids; HX.data.save();
    UI.app = to; UI.renderGrid(); UI.tiles[to].el.classList.add('moving'); UI.move(); UI.paint();
    return true;
  }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
})(window.HX = window.HX || {});
