// VIDAA (Hisense / Toshiba, Linux) device layer for the shared HorizonX web app (from samsung-tizen).
// VIDAA apps are web pages; there is no public API to list or open the TV's other apps, so the grid
// offers web TV services that open in this same browser window, and the Back key returns.
// ES5 only. In a desktop browser everything falls back to sample data.
(function (HX) {
  'use strict';
  var vidaa = typeof window.Hisense_GetModelName === 'function' || /VIDAA|Hisense/i.test(navigator.userAgent);
  var P = HX.platform = { tv: vidaa, selfId: 'HorizonX_debug', servicePort: 0 };

  // VIDAA reports Back as 8 (Backspace) or 461 depending on the model; Escape on some remotes.
  P.KEY = { LEFT: 37, UP: 38, RIGHT: 39, DOWN: 40, ENTER: 13, BACK: 10009, ESC: 27, BACKSPACE: 8, MENU: 18 };
  P.normalize = function (k) { return k === 8 || k === 461 ? P.KEY.BACK : k; };
  P.registerKeys = function () {};

  /** Web services that have a TV page and open from a browser app. */
  var WEB = [
    { id: 'web.youtube', name: 'YouTube', url: 'https://www.youtube.com/tv' },
    { id: 'web.youtubekids', name: 'YouTube Kids', url: 'https://www.youtubekids.com/tv' },
    { id: 'web.pluto', name: 'Pluto TV', url: 'https://pluto.tv/' },
    { id: 'web.twitch', name: 'Twitch', url: 'https://www.twitch.tv/' },
    { id: 'web.google', name: 'Internet', url: 'https://www.google.com/' }
  ];
  function knownApp(id) {
    var list = HX.catalog.apps;
    for (var i = 0; i < list.length; i++) { if (list[i].ids.indexOf(id) >= 0) { return list[i]; } }
    return null;
  }
  P.brandOf = function (name, id) {
    var known = id && knownApp(id);
    if (known) { return known; }
    var n = (name || '').toLowerCase(), list = HX.catalog.apps;
    for (var i = 0; i < list.length; i++) { if (n.indexOf(list[i].name.toLowerCase()) === 0) { return list[i]; } }
    return null;
  };
  P.apps = function (done) { done(WEB.map(function (a) { return { id: a.id, name: a.name, icon: '' }; })); };
  P.launch = function (id, fail) {
    for (var i = 0; i < WEB.length; i++) {
      if (WEB[i].id === id) { if (!vidaa) { HX.ui.toast('▶ ' + WEB[i].url); return; } window.location.href = WEB[i].url; return; }
    }
    if (fail) { fail(); }
  };
  // No public API for HDMI sources on VIDAA: the inputs page says so.
  P.sources = function (done) { done([]); };
  P.showSource = function () {};
  P.hideSource = function () {};
  P.exitToSystem = function () { try { window.close(); } catch (e) { /* not allowed */ } };
  P.service = function (path, done) { if (done) { done(null); } };
  P.info = function () {
    var out = { model: 'Browser preview', firmware: '', tizen: '' };
    try { out.model = window.Hisense_GetModelName(); out.firmware = window.Hisense_GetFirmWareVersion(); } catch (e) { /* not VIDAA */ }
    return out;
  };
  P.language = function () { return (navigator.language || 'es').slice(0, 2); };
  // VIDAA's native callbacks do not always update document.hidden. Preserve any existing
  // vendor handler, and feed the shared lifecycle without reloading/changing the design.
  function lifecycle(name, hidden) {
    var previous = window[name];
    window[name] = function () {
      try { if (typeof previous === 'function') { previous.apply(this, arguments); } }
      finally {
        P.hidden = hidden;
        var event = document.createEvent('Event'); event.initEvent('horizonxvisibilitychange', false, false);
        document.dispatchEvent(event);
      }
    };
  }
  if (vidaa) { lifecycle('Hisense_onAppHide', true); lifecycle('Hisense_onAppShow', false); }
})(window.HX = window.HX || {});
