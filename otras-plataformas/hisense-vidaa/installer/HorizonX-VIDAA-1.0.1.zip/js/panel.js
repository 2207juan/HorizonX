// Full-screen settings: categories on the left, their options on the right (rows and chips).
// Remote only: Up/Down move, Right or OK enter the options, Left at the first chip or Back return
// to the categories, Back there closes. No on-screen back arrows.
(function (HX) {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var P = HX.panel = { stack: [], rows: [], index: 0, col: 0, section: 0, inContent: false };

  function row(title, sub, action, chevron) { return { title: title, sub: sub || '', action: action, chev: chevron !== false }; }
  function chips(title, options, selected, pick) { return { title: title, options: options, selected: selected, pick: pick }; }
  function note(text) { return { note: text }; }
  function header(text) { return { header: text }; }

  function sections() {
    return [
      { title: HX.t('secHome'), page: home },
      { title: HX.t('secInputs'), page: inputsPage },
      { title: HX.t('secApps'), page: apps },
      { title: HX.t('secSystem'), page: system }
    ];
  }

  P.isOpen = function () { return !$('panel').hidden; };
  P.open = function (section) {
    $('toast').hidden = true; $('panel').hidden = false;
    P.list = sections(); P.section = section || 0; P.stack = [];
    $('sideTitle').textContent = HX.t('settings');
    renderSections(); showSection();
    // The inputs button opens straight into the list of inputs.
    setPane(!!section);
  };
  P.close = function () { $('panel').hidden = true; P.stack = []; HX.ui.paint(); };
  P.push = function (page) { P.stack.push(page); P.index = 0; P.col = 0; P.render(); setPane(true); };
  P.refresh = function () {
    var keep = P.index, col = P.col, page = P.stack.pop();
    P.stack.push(page.rebuild ? page.rebuild() : page); P.render();
    P.index = Math.min(keep, P.rows.length - 1); P.col = col; P.paint();
  };
  function renderSections() {
    var box = $('sections'); box.innerHTML = '';
    P.list.forEach(function (s) { var el = document.createElement('div'); el.className = 'sec'; el.textContent = s.title; box.appendChild(el); });
  }
  /** After a language change: same place, new texts. */
  function relabel() { P.list = sections(); renderSections(); $('sideTitle').textContent = HX.t('settings'); P.refresh(); }
  function showSection() { P.stack = [P.list[P.section].page()]; P.index = 0; P.col = 0; P.render(); }
  function setPane(content) { P.inContent = content && P.rows.length > 0; P.paint(); }

  P.render = function () {
    var page = P.stack[P.stack.length - 1];
    $('pageTitle').textContent = page.title;
    $('pageSub').textContent = page.sub || '';
    var body = $('pageBody'); body.innerHTML = '';
    var scroll = document.createElement('div'); scroll.id = 'pageScroll'; body.appendChild(scroll);
    P.rows = [];
    page.items.forEach(function (it) {
      var el = document.createElement('div');
      if (it.note) { el.className = 'note'; el.textContent = it.note; }
      else if (it.header) { el.className = 'header'; el.textContent = it.header; }
      else if (it.options) {
        el.className = 'row chiprow'; el.appendChild(document.createTextNode(it.title));
        var strip = document.createElement('div'); strip.className = 'chips';
        it.chips = it.options.map(function (o, i) {
          var c = document.createElement('span'); c.className = 'chip' + (i === it.selected ? ' on' : ''); c.textContent = o; strip.appendChild(c); return c;
        });
        el.appendChild(strip);
        P.rows.push({ el: el, item: it });
      } else {
        el.className = 'row' + (it.chev ? ' chev' : '');
        el.appendChild(document.createTextNode(it.title));
        if (it.sub) { var s = document.createElement('div'); s.className = 'sub'; s.textContent = it.sub; el.appendChild(s); }
        P.rows.push({ el: el, item: it });
      }
      scroll.appendChild(el);
    });
    P.paint();
  };
  P.paint = function () {
    var secs = $('sections').children;
    for (var i = 0; i < secs.length; i++) {
      secs[i].className = 'sec' + (i === P.section ? (P.inContent ? ' current' : ' focus') : '');
    }
    $('content').className = P.inContent ? '' : 'idle';
    P.rows.forEach(function (r, i) {
      var here = P.inContent && i === P.index;
      if (r.item.chips) {
        r.item.chips.forEach(function (c, j) { c.className = 'chip' + (j === r.item.selected ? ' on' : '') + (here && j === P.col ? ' focus' : ''); });
        r.el.classList.toggle('focus', here);
      } else { r.el.classList.toggle('focus', here); }
    });
    var r = P.rows[P.index]; if (!r) { return; }
    var h = $('pageBody').offsetHeight, s = $('pageScroll');
    if (!h) { return; }
    var y = Math.max(0, r.el.offsetTop - h + r.el.offsetHeight + 60);
    s.style.webkitTransform = s.style.transform = 'translateY(' + (-y) + 'px)';
  };
  P.key = function (k) {
    var K = HX.platform.KEY, back = k === K.BACK || k === K.ESC;
    if (!P.inContent) {
      if (back) { P.close(); }
      else if (k === K.UP && P.section > 0) { P.section--; showSection(); HX.ui.move(); P.paint(); }
      else if (k === K.DOWN && P.section < P.list.length - 1) { P.section++; showSection(); HX.ui.move(); P.paint(); }
      else if ((k === K.RIGHT || k === K.ENTER) && P.rows.length) { if (k === K.ENTER) { HX.ui.confirm(); } else { HX.ui.move(); } setPane(true); }
      return true;
    }
    var r = P.rows[P.index], width = r && r.item.chips ? r.item.chips.length : 1;
    if (back) {
      if (P.stack.length > 1) { P.stack.pop(); P.index = 0; P.col = 0; P.render(); } else { setPane(false); }
      HX.ui.move();
    } else if (k === K.UP && P.index > 0) { P.index--; P.col = 0; HX.ui.move(); P.paint(); }
    else if (k === K.DOWN && P.index < P.rows.length - 1) { P.index++; P.col = 0; HX.ui.move(); P.paint(); }
    else if (k === K.LEFT) { if (P.col > 0) { P.col--; P.paint(); } else { if (P.stack.length > 1) { showSection(); } setPane(false); } HX.ui.move(); }
    else if (k === K.RIGHT && P.col < width - 1) { P.col++; HX.ui.move(); P.paint(); }
    else if (k === K.ENTER && r) {
      HX.ui.confirm();
      if (r.item.chips) { r.item.selected = P.col; r.item.pick(P.col); P.paint(); }
      else if (r.item.action) { r.item.action(); }
    }
    return true;
  };

  function settings() { return HX.data.settings; }
  function save() { HX.data.save(); }

  function home() {
    var s = settings(), langs = [['', HX.t('automatic')], ['es', 'Español'], ['en', 'English'], ['pt', 'Português']];
    var li = 0; langs.forEach(function (l, i) { if (l[0] === s.lang) { li = i; } });
    return { title: HX.t('secHome'), sub: HX.t('secHomeSub'), rebuild: home, items: [
      row(HX.t('name'), s.name || '—', function () { P.editName(); }),
      chips(HX.t('avatar'), ['1', '2', '3', '4'], s.avatar - 1, function (i) { s.avatar = i + 1; save(); HX.ui.profile(); }),
      chips(HX.t('language'), langs.map(function (l) { return l[1]; }), li, function (i) { s.lang = langs[i][0]; save(); HX.setLanguage(); relabel(); }),
      header(HX.t('home')),
      chips(HX.t('weatherShort'), [HX.t('yes'), HX.t('no')], s.weather ? 0 : 1, function (i) { s.weather = i === 0; save(); HX.refreshWeather(); }),
      chips(HX.t('spotlight'), [HX.t('yes'), HX.t('no')], s.spotlight ? 0 : 1, function (i) { s.spotlight = i === 0; save(); if (!s.spotlight) { HX.ui.spot(null); } }),
      chips(HX.t('sounds'), [HX.t('yes'), HX.t('no')], s.sounds ? 0 : 1, function (i) { s.sounds = i === 0; save(); })
    ] };
  }
  /** Text field over the focused row; the TV opens its on-screen keyboard (IME). */
  P.editName = function () {
    var r = P.rows[P.index], input = document.createElement('input');
    input.type = 'text'; input.value = settings().name; input.maxLength = 24;
    input.style.cssText = 'position:absolute;left:20px;right:20px;top:16px;height:60px;font:500 27px Outfit,sans-serif;border-radius:16px;border:0;padding:0 18px;';
    r.el.appendChild(input); P.editing = input; input.focus();
    function finish(saveIt) {
      if (!P.editing) { return; }
      if (saveIt) { settings().name = input.value.trim().slice(0, 24); save(); HX.ui.profile(); }
      P.editing = null; input.blur(); P.refresh();
    }
    input.addEventListener('keydown', function (e) {
      var k = e.keyCode;
      if (k === 65376 || k === 13) { e.preventDefault(); finish(true); }          // IME Done / Enter
      else if (k === 65385 || k === 10009 || k === 27) { e.preventDefault(); finish(false); } // IME Cancel / Back
      e.stopPropagation();
    });
    input.addEventListener('blur', function () { finish(true); });
  };
  function apps() {
    var s = settings();
    var items = HX.ui.apps.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }).map(function (a) {
      var hidden = s.hidden.indexOf(a.id) >= 0;
      return chips(a.name, [HX.t('on'), HX.t('hidden')], hidden ? 1 : 0, function (i) {
        var at = s.hidden.indexOf(a.id);
        if (i === 1 && at < 0) { s.hidden.push(a.id); } else if (i === 0 && at >= 0) { s.hidden.splice(at, 1); }
        save(); HX.ui.renderGrid();
      });
    });
    return { title: HX.t('secApps'), sub: HX.t('secAppsSub'), rebuild: apps, items: items };
  }
  function inputsPage() {
    var page = { title: HX.t('secInputs'), items: [note(HX.t('notAvailable'))] };
    HX.platform.sources(function (list) {
      if (!list.length) { return; }
      page.items = list.map(function (src) {
        return row(src.name, src.connected ? '' : '—', function () {
          P.close();
          HX.platform.showSource(src, function () { $('sourceView').hidden = false; $('stage').style.visibility = 'hidden'; $('dock').style.visibility = 'hidden'; HX.sourceOpen = true; });
        }, false);
      });
      if (P.isOpen() && P.stack[0] === page) { P.render(); }
    });
    return page;
  }
  function system() {
    var s = settings(), i = HX.platform.info();
    var items = [];
    // Only where a boot service can reopen HorizonX (Tizen); VIDAA has none.
    if (HX.platform.servicePort) {
      items.push(chips(HX.t('useAsHome'), [HX.t('on'), HX.t('off')], s.asHome ? 0 : 1, function (n) {
        s.asHome = n === 0; save(); HX.platform.service('/config?asHome=' + (s.asHome ? 1 : 0));
      }));
    }
    items.push(note('HorizonX' + (i.firmware ? ' · ' + i.firmware : '')));
    return { title: HX.t('secSystem'), sub: i.model + (i.tizen ? ' · Tizen ' + i.tizen : ''), rebuild: system, items: items };
  }
})(window.HX = window.HX || {});
