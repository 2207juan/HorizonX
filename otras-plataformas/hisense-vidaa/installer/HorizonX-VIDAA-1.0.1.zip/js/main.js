// Boot, language and key routing. Preview parameters (desktop browser only), for screenshots:
//   index.html?lang=en&name=Alex&avatar=1&zone=apps&app=3&panel=0&content=1
(function (HX) {
  'use strict';
  var UI = HX.ui, D = HX.data, K = HX.platform.KEY;
  var params = {};
  location.search.replace(/[?&]([^=&]+)=([^&]*)/g, function (_, k, v) { params[k] = decodeURIComponent(v); });
  if (!HX.platform.tv) {
    if (params.lang) { D.settings.lang = params.lang; }
    if (params.name !== undefined) { D.settings.name = params.name; }
    if (params.avatar) { D.settings.avatar = +params.avatar; }
  }

  HX.setLanguage = function () {
    var want = D.settings.lang || HX.platform.language();
    HX.lang = HX.strings[want] ? want : 'en';
    document.documentElement.lang = HX.lang;
    UI.profile(); UI.clock(); UI.renderRail(); UI.paint();
    HX.refreshWeather();
  };
  HX.t = function (key, vars) {
    var table = HX.strings[HX.lang] || HX.strings.es, text = table[key] || HX.strings.es[key] || key;
    for (var v in vars || {}) { text = text.replace('{' + v + '}', vars[v]); }
    return text;
  };
  HX.refreshWeather = function () { D.weather(UI.weather); };

  var appRequest = 0;
  function loadApps() {
    var request = ++appRequest;
    HX.platform.apps(function (apps) {
      if (request !== appRequest) { return; }
      UI.apps = apps;
      HX.platform.service('/apps?ids=' + apps.map(function (a) { return encodeURIComponent(a.id); }).join(','));
      UI.renderGrid(); UI.renderRail(); UI.paint();
      D.explore(apps, function (items) { if (request !== appRequest) { return; } UI.explore = items; if (UI.tab === 0) { UI.renderRail(); UI.paint(); } });
    });
  }

  // Some remotes send only DOWN/UP when held. A timer must not depend on key-repeat.
  var enterDown = 0, longDone = false, holdTimer = 0;
  function cancelHold() { clearTimeout(holdTimer); holdTimer = 0; enterDown = 0; longDone = false; }
  window.addEventListener('blur', cancelHold);
  document.addEventListener('keydown', function (e) {
    var k = HX.platform.normalize ? HX.platform.normalize(e.keyCode) : e.keyCode;
    if (HX.panel.editing) { return; }
    if (HX.sourceOpen) {
      if (k === K.BACK || k === K.ESC) { HX.platform.hideSource(); HX.sourceOpen = false; document.getElementById('sourceView').hidden = true;
        document.getElementById('stage').style.visibility = ''; document.getElementById('dock').style.visibility = ''; e.preventDefault(); }
      return;
    }
    if (k === K.ENTER) {
      if (!enterDown) {
        enterDown = Date.now(); longDone = false;
        holdTimer = setTimeout(function () {
          if (enterDown && !HX.panel.isOpen() && !HX.sourceOpen && !document.hidden && UI.zone === 'apps' && !UI.moving) { longDone = true; UI.longPress(); }
        }, 550);
      }
      e.preventDefault(); return;
    }
    if (enterDown) { cancelHold(); }
    var handled = HX.panel.isOpen() ? HX.panel.key(k) : UI.key(k);
    if (handled) { e.preventDefault(); }
  });
  document.addEventListener('keyup', function (e) {
    if (e.keyCode !== K.ENTER || HX.panel.editing || HX.sourceOpen) { return; }
    if (!enterDown) { return; }
    var wasLong = longDone; cancelHold();
    if (wasLong) { return; }
    if (HX.panel.isOpen()) { HX.panel.key(K.ENTER); } else if (UI.moving) { UI.key(K.ENTER); } else { UI.activate(); }
  });
  // Returning to HorizonX (Home pressed elsewhere): start again from the content row.
  document.addEventListener('visibilitychange', function () {
    cancelHold();
    if (document.hidden) { if (UI.suspend) { UI.suspend(); } return; }
    if (!document.hidden) { UI.clock(); if (!HX.panel.isOpen()) { UI.zone = 'rail'; UI.paint(); } loadApps(); }
  });

  HX.platform.registerKeys();
  HX.setLanguage();
  loadApps();
  HX.platform.service('/config?asHome=' + (D.settings.asHome ? 1 : 0));
  setInterval(function () { if (!document.hidden) { UI.clock(); } }, 15000);
  setInterval(function () { if (!document.hidden) { HX.refreshWeather(); } }, 30 * 60000);

  // Preview-only state for screenshots.
  if (!HX.platform.tv) {
    setTimeout(function () {
      if (params.zone) { UI.zone = params.zone; }
      if (params.app) { UI.app = +params.app; }
      if (params.rail) { UI.rail = +params.rail; UI.scrollRail(false); }
      if (params.tab) { UI.tab = +params.tab; UI.renderRail(); }
      UI.paint();
      if (params.panel) { HX.panel.open(+params.panel > 0 ? +params.panel : 0); if (params.content) { HX.panel.key(K.RIGHT); } }
    }, 50);
  }
})(window.HX = window.HX || {});
