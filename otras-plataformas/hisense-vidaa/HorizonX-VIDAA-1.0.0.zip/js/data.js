// Settings, weather, "Explorar" (TVmaze, filtered by the streaming apps installed) and recents.
(function (HX) {
  'use strict';
  var KEY = 'horizonx.settings.v1';
  var D = HX.data = {};
  var defaults = { name: '', avatar: 1, lang: '', weather: true, spotlight: true, sounds: true, order: [], hidden: [], recent: [], asHome: true };
  D.settings = (function () {
    var s = {};
    try { s = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { s = {}; }
    for (var k in defaults) { if (!(k in s)) { s[k] = defaults[k]; } }
    return s;
  })();
  D.save = function () { try { localStorage.setItem(KEY, JSON.stringify(D.settings)); } catch (e) { /* storage full */ } };

  function get(url, done) {
    var x = new XMLHttpRequest();
    x.open('GET', url);
    x.timeout = 8000;
    x.onload = function () { if (x.status === 200) { try { done(JSON.parse(x.responseText)); return; } catch (e) { /* bad JSON */ } } done(null); };
    x.onerror = x.ontimeout = function () { done(null); };
    x.send();
  }
  function cached(name, ttl, fetch, done) {
    var raw = null;
    try { raw = JSON.parse(localStorage.getItem('hx.cache.' + name) || 'null'); } catch (e) { raw = null; }
    if (raw && Date.now() - raw.at < ttl) { done(raw.value); return; }
    fetch(function (value) {
      if (value) { try { localStorage.setItem('hx.cache.' + name, JSON.stringify({ at: Date.now(), value: value })); } catch (e) { /* full */ } }
      done(value || (raw && raw.value) || null);
    });
  }

  // WMO weather codes from Open-Meteo; labels are Spanish keys translated by HX.t.
  function describe(code, day) {
    if (code <= 1) { return { label: code === 0 ? (day ? 'Soleado' : 'Despejado') : 'Despejado', icon: day ? 'sun' : 'moon' }; }
    if (code === 2) { return { label: 'Parcialmente nublado', icon: 'cloud' }; }
    if (code === 3) { return { label: 'Nublado', icon: 'cloud' }; }
    if (code === 45 || code === 48) { return { label: 'Niebla', icon: 'cloud' }; }
    if (code >= 51 && code <= 57) { return { label: 'Llovizna', icon: 'rain' }; }
    if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) { return { label: 'Lluvia', icon: 'rain' }; }
    if ((code >= 71 && code <= 77) || code === 85 || code === 86) { return { label: 'Nieve', icon: 'cloud' }; }
    if (code >= 95) { return { label: 'Tormenta', icon: 'rain' }; }
    return { label: 'Nublado', icon: 'cloud' };
  }
  D.weather = function (done) {
    if (!D.settings.weather) { done(null); return; }
    // Approximate location from the public IP; a second provider when the first is rate-limited.
    cached('place2', 7 * 864e5, function (cb) {
      get('https://ipwho.is/?fields=latitude,longitude,city', function (a) {
        if (a && a.latitude) { cb(a); return; }
        get('https://get.geojs.io/v1/ip/geo.json', function (b) { cb(b && b.latitude ? { latitude: +b.latitude, longitude: +b.longitude, city: b.city || '' } : null); });
      });
    }, function (place) {
      if (!place) { done(null); return; }
      cached('weather2', 30 * 6e4, function (cb) {
        get('https://api.open-meteo.com/v1/forecast?latitude=' + place.latitude + '&longitude=' + place.longitude +
          '&current=temperature_2m,weather_code,is_day&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=4&timezone=auto', cb);
      }, function (w) {
        if (!w || !w.current) { done(null); return; }
        var d = describe(w.current.weather_code, w.current.is_day === 1), days = [], today = null;
        var daily = w.daily || {}, times = daily.time || [], now = new Date();
        var key = now.getFullYear() + '-' + ('0' + (now.getMonth() + 1)).slice(-2) + '-' + ('0' + now.getDate()).slice(-2);
        for (var i = 0; i < times.length; i++) {
          var day = { date: times[i], icon: describe(daily.weather_code[i], true).icon, max: Math.round(daily.temperature_2m_max[i]), min: Math.round(daily.temperature_2m_min[i]) };
          if (times[i] === key) { today = day; } else if (times[i] > key && days.length < 3) { days.push(day); }
        }
        done({ celsius: Math.round(w.current.temperature_2m), label: d.label, icon: d.icon, city: place.city || '',
               max: today && today.max, min: today && today.min, days: days });
      });
    });
  };

  // Streaming service names as TVmaze reports them, matched against installed app names.
  var SERVICES = { 'netflix': ['Netflix'], 'prime video': ['Prime Video', 'Amazon Prime Video'], 'disney+': ['Disney+'],
    'max': ['HBO Max', 'Max'], 'hbo max': ['HBO Max', 'Max'], 'paramount+': ['Paramount+'], 'apple tv': ['Apple TV+', 'Apple TV'],
    'crunchyroll': ['Crunchyroll'], 'peacock': ['Peacock'], 'hulu': ['Hulu'], 'vix': ['ViX', 'ViX+'], 'globoplay': ['Globoplay'] };
  function channelsFor(apps) {
    var map = {};
    apps.forEach(function (a) {
      var n = a.name.toLowerCase();
      for (var k in SERVICES) { if (n.indexOf(k) === 0) { SERVICES[k].forEach(function (c) { map[c.toLowerCase()] = a; }); } }
    });
    return map;
  }
  var GENRES = { es: { Drama: 'Drama', Comedy: 'Comedia', Action: 'Acción', Animation: 'Animación', Anime: 'Anime', Crime: 'Crimen', Thriller: 'Suspenso',
      'Science-Fiction': 'Ciencia ficción', Fantasy: 'Fantasía', Horror: 'Terror', Romance: 'Romance', Family: 'Familia', Children: 'Infantil',
      Adventure: 'Aventura', Mystery: 'Misterio', Documentary: 'Documental', Music: 'Música', Sports: 'Deportes', History: 'Historia', Reality: 'Reality' },
    pt: { Drama: 'Drama', Comedy: 'Comédia', Action: 'Ação', Animation: 'Animação', Crime: 'Crime', Thriller: 'Suspense', 'Science-Fiction': 'Ficção científica',
      Fantasy: 'Fantasia', Horror: 'Terror', Family: 'Família', Children: 'Infantil', Adventure: 'Aventura', Mystery: 'Mistério', Documentary: 'Documentário' } };
  function genre(g) { var t = GENRES[HX.lang]; return (t && t[g]) || g; }
  function seeded(seed) { return function () { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }; }

  /** Trending shows on the installed services, reshuffled once a day. */
  D.explore = function (apps, done) {
    cached('tvmaze', 10 * 36e5, function (cb) {
      // Four days of streaming premieres, fetched one after another to stay light on the TV.
      var days = [0, 1, 2, 3].map(function (n) {
        var d = new Date(Date.now() - n * 864e5);
        return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
      }), all = [];
      (function next() {
        if (!days.length) { collect(all); return; }
        get('https://api.tvmaze.com/schedule/web?date=' + days.shift(), function (list) { if (list) { all = all.concat(list); } next(); });
      })();
      function collect(list) {
        if (!list.length) { cb(null); return; }
        var seen = {}, out = [];
        list.forEach(function (e) {
          var s = e._embedded && e._embedded.show;
          if (!s || seen[s.id] || !s.image) { return; }
          seen[s.id] = 1;
          out.push({ id: s.id, name: s.name, image: (s.image.original || s.image.medium).replace('http://', 'https://'),
            channel: (s.webChannel && s.webChannel.name) || (s.network && s.network.name) || '', weight: s.weight || 0, genre: (s.genres || [])[0] || '' });
        });
        out.sort(function (a, b) { return b.weight - a.weight; });
        cb(out.slice(0, 60));
      }
    }, function (shows) {
      if (!shows) { done([]); return; }
      var map = channelsFor(apps), any = Object.keys(map).length === 0, picked = [];
      shows.forEach(function (s) {
        var app = map[s.channel.toLowerCase()];
        if (app || any) { picked.push({ title: s.name, image: s.image, meta: [HX.t('series'), genre(s.genre), app ? app.name : s.channel].filter(Boolean).join(' · '), app: app || null }); }
      });
      var rnd = seeded(Math.floor(Date.now() / 864e5)), head = picked.slice(0, 3), tail = picked.slice(3);
      for (var i = tail.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = tail[i]; tail[i] = tail[j]; tail[j] = t; }
      var items = head.concat(tail).slice(0, 16);
      if (!items.length) { done(items); return; }
      // Landscape art for the large first card (one extra request, cached with the list).
      var first = shows.filter(function (s) { return s.name === items[0].title; })[0];
      cached('backdrop.' + first.id, 10 * 36e5, function (cb) { get('https://api.tvmaze.com/shows/' + first.id + '/images', cb); }, function (images) {
        (images || []).some(function (im) {
          if (im.type !== 'background') { return false; }
          var r = im.resolutions || {}, src = (r.medium || r.original || {}).url;
          if (src) { items[0].wide = src.replace('http://', 'https://'); }
          return !!src;
        });
        done(items);
      });
    });
  };

  D.remember = function (app) {
    var r = D.settings.recent.filter(function (x) { return x.id !== app.id; });
    r.unshift({ id: app.id, name: app.name, at: Date.now() });
    D.settings.recent = r.slice(0, 12);
    D.save();
  };
})(window.HX = window.HX || {});
