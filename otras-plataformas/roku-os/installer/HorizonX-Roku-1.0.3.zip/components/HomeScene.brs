sub init()
    resolution = m.top.currentDesignResolution
    if resolution <> invalid then m.top.findNode("canvas").scale = [resolution.width / 1920.0, resolution.height / 1080.0]
    m.strings = loadStrings()
    m.rows = m.top.findNode("rows")
    m.panel = m.top.findNode("panel")
    m.settings = m.top.findNode("settings")
    m.rows.observeField("rowItemSelected", "onSelect")
    m.settings.observeField("itemSelected", "onSetting")
    m.weatherText = ""
    applyProfile()
    tick()
    m.clock = CreateObject("roSGNode", "Timer")
    m.clock.duration = 15
    m.clock.repeat = true
    m.clock.observeField("fire", "tick")
    m.clock.control = "start"
    m.top.findNode("loading").text = "…"
    m.rows.setFocus(true)
    loadData()
end sub

sub loadData()
    m.explore = CreateObject("roSGNode", "DataTask")
    m.explore.observeField("result", "onData")
    m.explore.request = "explore"
    m.explore.control = "run"
    if prefGet("weather", "1") = "1" then
        m.weatherTask = CreateObject("roSGNode", "DataTask")
        m.weatherTask.observeField("result", "onData")
        m.weatherTask.request = "weather"
        m.weatherTask.control = "run"
    else
        m.weatherValue = invalid
        showWeather()
    end if
end sub

sub applyProfile()
    name = prefGet("name", "")
    if name = "" then
        m.top.findNode("hello").text = txt(m.strings, "hello")
    else
        m.top.findNode("hello").text = txt(m.strings, "helloName", name)
    end if
    m.top.findNode("question").text = txt(m.strings, "question")
    m.top.findNode("avatar").uri = "pkg:/images/avatar-" + prefGet("avatar", "1") + ".png"
end sub

sub tick()
    parts = nowParts(m.strings.lang)
    m.top.findNode("clock").text = parts.time
    m.top.findNode("date").text = parts.date
    layoutTopbar()
end sub

' Centre the glass bar around its labels: Roku has no flex layout.
sub layoutTopbar()
    clock = m.top.findNode("clock")
    date = m.top.findNode("date")
    weather = m.top.findNode("weather")
    weather.text = m.weatherText
    x = 30 + clock.boundingRect().width + 34
    date.translation = [x, 0]
    x = x + date.boundingRect().width + 34
    weather.translation = [x, 0]
    if m.weatherText <> "" then x = x + weather.boundingRect().width + 30 else x = x - 4
    m.top.findNode("topGlass").width = x
    m.top.findNode("topbar").translation = [(1920 - x) / 2, 28]
end sub

sub onData(event as Object)
    r = event.getData()
    if r.kind = "weather" then
        if prefGet("weather", "1") = "1" then m.weatherValue = r.value else m.weatherValue = invalid
        showWeather()
        return
    end if
    m.lastExplore = r
    buildRows(r)
end sub

sub showWeather()
    m.weatherText = ""
    if prefGet("weather", "1") = "1" and m.weatherValue <> invalid then m.weatherText = txt(m.strings, m.weatherValue.label) + "  " + m.weatherValue.celsius.ToStr() + "° C"
    layoutTopbar()
end sub

sub buildRows(r as Object)
    m.services = r.services
    m.items = r.items
    content = CreateObject("roSGNode", "ContentNode")
    explore = content.createChild("ContentNode")
    explore.title = txt(m.strings, "explore")
    for each it in r.items
        c = explore.createChild("ContentNode")
        c.title = it.title
        c.HDPosterUrl = it.poster
        meta = txt(m.strings, "series")
        if it.genre <> "" then meta = meta + " · " + genreName(it.genre, m.strings.lang)
        c.description = meta + " · " + it.app
    end for
    services = content.createChild("ContentNode")
    services.title = txt(m.strings, "yourServices")
    for each s in r.services
        c = services.createChild("ContentNode")
        c.title = s.name
        c.shortDescriptionLine2 = s.color
    end for
    m.top.findNode("loading").visible = false
    m.rows.content = content
end sub

' Roku apps cannot open other apps (no ECP from inside an app), so selecting tells the user where.
sub onSelect(event as Object)
    sel = event.getData()
    row = sel[0]
    col = sel[1]
    if row = 0 then
        it = m.items[col]
        showMessage(it.title, txt(m.strings, "openOnRoku", it.app))
    else
        s = m.services[col]
        showMessage(s.name, txt(m.strings, "openOnRoku", s.name))
    end if
end sub

sub showMessage(title as String, text as String)
    m.top.findNode("panelTitle").text = title
    m.top.findNode("panelText").text = text
    m.top.findNode("panelText").visible = true
    m.settings.visible = false
    m.panel.visible = true
    m.mode = "message"
end sub

sub openSettings()
    m.top.findNode("panelTitle").text = txt(m.strings, "settings")
    m.top.findNode("panelText").visible = false
    langNames = { "": txt(m.strings, "automatic"), es: "Español", en: "English", pt: "Português" }
    weatherOn = txt(m.strings, "off")
    if prefGet("weather", "1") = "1" then weatherOn = txt(m.strings, "on")
    list = CreateObject("roSGNode", "ContentNode")
    for each label in [
        txt(m.strings, "name") + ":  " + prefGet("name", "—"),
        txt(m.strings, "avatar") + ":  " + prefGet("avatar", "1"),
        txt(m.strings, "language") + ":  " + langNames[prefs().Read("lang")],
        txt(m.strings, "weather") + ":  " + weatherOn,
        txt(m.strings, "screensaver")
    ]
        item = list.createChild("ContentNode")
        item.title = label
    end for
    m.settings.content = list
    m.settings.visible = true
    m.panel.visible = true
    m.settings.setFocus(true)
    m.mode = "settings"
end sub

sub onSetting(event as Object)
    i = event.getData()
    if i = 0 then
        askName()
        return
    else if i = 1 then
        prefSet("avatar", (Val(prefGet("avatar", "1")) mod 4 + 1).ToStr())
    else if i = 2 then
        order = ["", "es", "en", "pt"]
        current = prefs().Read("lang")
        nextIndex = 0
        for k = 0 to 3
            if order[k] = current then nextIndex = (k + 1) mod 4
        end for
        prefSet("lang", order[nextIndex])
        m.strings = loadStrings()
        tick()
        showWeather()
        if m.lastExplore <> invalid then buildRows(m.lastExplore)
    else if i = 3 then
        if prefGet("weather", "1") = "1" then prefSet("weather", "0") else prefSet("weather", "1")
        if m.weatherTask <> invalid then m.weatherTask.control = "stop"
        if prefGet("weather", "1") = "1" then
            m.weatherTask = CreateObject("roSGNode", "DataTask")
            m.weatherTask.observeField("result", "onData")
            m.weatherTask.request = "weather"
            m.weatherTask.control = "run"
        else
            m.weatherValue = invalid
            showWeather()
        end if
    else if i = 4 then
        showMessage(txt(m.strings, "screensaver"), txt(m.strings, "screensaverHelp"))
        return
    end if
    applyProfile()
    openSettings()
    m.settings.jumpToItem = i
end sub

sub askName()
    dialog = CreateObject("roSGNode", "StandardKeyboardDialog")
    dialog.title = txt(m.strings, "name")
    dialog.text = prefGet("name", "")
    dialog.buttons = [txt(m.strings, "save")]
    dialog.observeField("buttonSelected", "onName")
    m.top.dialog = dialog
end sub

sub onName(event as Object)
    prefSet("name", Left(m.top.dialog.text, 24))
    m.top.dialog.close = true
    applyProfile()
    openSettings()
end sub

sub closePanel()
    m.panel.visible = false
    m.mode = ""
    m.rows.setFocus(true)
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    if key = "options" then
        if m.panel.visible then closePanel() else openSettings()
        return true
    end if
    if key = "back" and m.panel.visible then
        closePanel()
        return true
    end if
    return false
end function
