sub init()
    resolution = m.top.currentDesignResolution
    if resolution <> invalid then m.top.findNode("canvas").scale = [resolution.width / 1920.0, resolution.height / 1080.0]
    m.strings = loadStrings()
    m.block = m.top.findNode("block")
    m.fade = m.top.findNode("fade")
    m.fade.observeField("state", "onFaded")
    m.spots = [[120, 640], [1040, 640], [120, 160], [1040, 160], [560, 420]]
    m.spot = 0
    update()
    timer = CreateObject("roSGNode", "Timer")
    timer.duration = 60
    timer.repeat = true
    timer.observeField("fire", "move")
    timer.control = "start"
    m.timer = timer
    if prefGet("weather", "1") = "1" then
        m.task = CreateObject("roSGNode", "DataTask")
        m.task.observeField("result", "onWeather")
        m.task.request = "weather"
        m.task.control = "run"
    end if
end sub
sub update()
    p = nowParts(m.strings.lang)
    m.top.findNode("time").text = p.time
    m.top.findNode("date").text = p.date
end sub
sub move()
    m.spot = (m.spot + 1) mod m.spots.Count()
    m.fade.control = "start"
end sub
sub onFaded()
    if m.fade.state <> "stopped" then return
    if m.block.opacity < 0.5 then
        m.block.translation = m.spots[m.spot]
        update()
        m.top.findNode("fadeIn").control = "start"
    end if
end sub
sub onWeather(event as Object)
    r = event.getData()
    if r.value <> invalid then m.top.findNode("weather").text = txt(m.strings, r.value.label) + "  " + r.value.celsius.ToStr() + "° C"
end sub
