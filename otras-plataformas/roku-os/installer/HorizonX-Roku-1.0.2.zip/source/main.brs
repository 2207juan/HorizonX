' HorizonX for Roku: a HorizonX-style hub and screensaver. Roku apps cannot open other apps or
' replace the Home screen, so this channel shows your greeting, clock, weather and what is new
' on the services you have installed. The PC assistant can open apps over ECP from outside.

sub Main(args as Dynamic)
    showScene("HomeScene", args)
end sub

' Entry point Roku uses when HorizonX is chosen in Settings > Theme > Screensavers.
sub RunScreenSaver()
    showScene("Screensaver", invalid)
end sub

sub showScene(name as String, args as Dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)
    scene = screen.CreateScene(name)
    screen.Show()
    if args <> invalid and type(args) = "roAssociativeArray" then scene.launchArgs = args
    while true
        msg = Wait(0, port)
        if type(msg) = "roSGScreenEvent" and msg.IsScreenClosed() then return
    end while
end sub
