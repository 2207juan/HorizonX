' Shared by HomeScene and Screensaver: texts, preferences and date formatting.

function loadStrings() as Object
    all = ParseJson(ReadAsciiFile("pkg:/data/strings.json"))
    lang = prefs().Read("lang")
    if lang = "" then lang = Left(CreateObject("roDeviceInfo").GetCurrentLocale(), 2)
    table = all[lang]
    if table = invalid then
        table = all["en"]
        lang = "en"
    end if
    table.lang = lang
    return table
end function

function txt(strings as Object, key as String, name = "" as String) as String
    text = strings[key]
    if text = invalid then text = key
    return text.Replace("{name}", name).Replace("{app}", name)
end function

function prefs() as Object
    return CreateObject("roRegistrySection", "horizonx")
end function

function prefGet(key as String, fallback as String) as String
    v = prefs().Read(key)
    if v = "" then return fallback
    return v
end function

sub prefSet(key as String, value as String)
    r = prefs()
    r.Write(key, value)
    r.Flush()
end sub

function weekdayName(index as Integer, lang as String) as String
    names = { es: ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"], en: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], pt: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"] }
    list = names[lang]
    if list = invalid then list = names.en
    return list[index]
end function

function monthName(index as Integer, lang as String) as String
    names = { es: ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"], en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], pt: ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"] }
    list = names[lang]
    if list = invalid then list = names.en
    return list[index - 1]
end function

function nowParts(lang as String) as Object
    d = CreateObject("roDateTime")
    d.ToLocalTime()
    weekday = d.GetDayOfWeek()
    return {
        time: d.GetHours().ToStr() + ":" + Right("0" + d.GetMinutes().ToStr(), 2),
        date: weekdayName(weekday, lang) + " " + d.GetDayOfMonth().ToStr() + " " + monthName(d.GetMonth(), lang)
    }
end function

function genreName(genre as String, lang as String) as String
    es = { Drama: "Drama", Comedy: "Comedia", Action: "Acción", Animation: "Animación", Anime: "Anime", Crime: "Crimen", Thriller: "Suspenso", "Science-Fiction": "Ciencia ficción", Fantasy: "Fantasía", Horror: "Terror", Romance: "Romance", Family: "Familia", Children: "Infantil", Adventure: "Aventura", Mystery: "Misterio", Documentary: "Documental", Music: "Música", Sports: "Deportes", History: "Historia", Food: "Cocina", Reality: "Reality" }
    pt = { Drama: "Drama", Comedy: "Comédia", Action: "Ação", Animation: "Animação", Crime: "Crime", Thriller: "Suspense", "Science-Fiction": "Ficção científica", Fantasy: "Fantasia", Horror: "Terror", Family: "Família", Children: "Infantil", Adventure: "Aventura", Mystery: "Mistério", Documentary: "Documentário", Food: "Culinária" }
    table = invalid
    if lang = "es" then table = es
    if lang = "pt" then table = pt
    if table <> invalid and table[genre] <> invalid then return table[genre]
    return genre
end function
