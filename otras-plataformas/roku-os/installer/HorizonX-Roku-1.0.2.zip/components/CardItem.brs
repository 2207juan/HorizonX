sub init()
    m.poster = m.top.findNode("poster")
    m.tile = m.top.findNode("tile")
end sub
sub show()
    c = m.top.itemContent
    isService = c.shortDescriptionLine2 <> ""
    m.poster.visible = not isService
    m.tile.visible = isService
    if isService then
        m.top.findNode("tileBg").blendColor = c.shortDescriptionLine2
        m.top.findNode("tileName").text = c.title
    else
        m.top.findNode("art").uri = c.HDPosterUrl
        m.top.findNode("title").text = c.title
        m.top.findNode("meta").text = c.description
    end if
end sub
sub focus()
    if m.top.focusPercent > 0.5 then
        m.top.findNode("title").color = "0xF5F6FBFF"
    else
        m.top.findNode("title").color = "0xC3C9D8FF"
    end if
end sub
